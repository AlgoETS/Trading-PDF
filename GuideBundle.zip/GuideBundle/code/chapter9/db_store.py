# Imports
import boto3
import time
from pprint import pprint
from boto3.dynamodb.conditions import Key

# Specify the target
dynamodb = boto3.resource('dynamodb')

def orderExecution(): 
    # If placing in order Execution in ibProgram1.py, use the following line:
        # After this line: app.placeOrder(nextID, contractObject, orderObject)
        # Place this line: put_data(contractObject.stock, orderObject.totalQuantity)

    # Simple write. In ibProgram1.py, this would likely be removed by the above lines
    response = put_data("AAPL", 101)
    return response

# Function to place a recently purchased stock into the database
def put_data(symbol, quantity): 

    # Define the financial data table we will write to
    table = dynamodb.Table('fin_data')

    # We will later sort by time, so prepare in variable
    current_time = int(time.time())

    # Define the item values. These are drawn from the parameters and time variable
    response = table.put_item(
       Item={
            'symbol': symbol,
            'timestamp': current_time,
            'quantity': quantity,
        }
    )

    # Return response for printing
    return response

# Function to search Database. In this example, we are searching by symbol
def query_data(symbol, time_range):

    # Define target table and save time 
    table = dynamodb.Table('fin_data')
    current_time = int(time.time())

    # Query by the key (which we defined when creating the table as symbol) and a specific time range passed as an argument 
    response = table.query(
        KeyConditionExpression=Key('symbol').eq(symbol) & Key('timestamp').between(time_range[0], time_range[1])
    )

    # Return an array that we will iterate over later
    return response['Items']


if __name__ == '__main__':

    # Let's write first
    response = orderExecution()

    # Let's define a limit in minutes and store unix time
    time_limit = 10
    current_time = int(time.time())

    # End time will then be the current time minus the limit in seconds
    # Which would be the quantity of *time_limit seconds* into the past
    end_time = current_time - (time_limit*60)
    time_range = (end_time, current_time)

    # Query by ticker passed as an argument
    symbols = query_data("AAPL", time_range)

    # Iterate over the response and print all information returned
    for symbol in symbols:
        print(symbol['symbol'], ":", symbol['quantity'])

    # Print the output
    pprint(symbols, sort_dicts=False)