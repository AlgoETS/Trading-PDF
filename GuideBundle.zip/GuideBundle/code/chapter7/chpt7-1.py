# Below are the import statements 

from bs4 import BeautifulSoup
import requests
import time 

# Below are the global variables

textContent = []	# Holds the headlines in an array 
cycleCount = 0 		# Stores the frequency of requests made to the server 

# Below is the input area

def economistSearch():
	page_link = 'https://www.economist.com/'	# Page Url to point request where to crawl 
	page_response = requests.get(page_link, timeout=20)	# Get request to ask for page content
	page_content = BeautifulSoup(page_response.content, "html.parser")	# Ask Beautiful soup to parse for content

	for link in page_content.find_all("span", class_="flytitle-and-title__title"):	# Finds all the spans with the class flytitle-and-title__title
		if link.text not in textContent:
			# print(link.text)	# Prints the title so we can verify correct operation 
			textContent.append(link.text)	# Appends the headline to our main array 

	time.sleep(5) # Creates a crawl delay of 5 seconds (which the Economist requires in their robots.txt file)

while True: 

	economistSearch()	# Calls our main scraping method 
	cycleCount += 1		# Tracks the method calls 
	print("Search DONE, Cycle: + " + str(cycleCount))	# An optional printout to display how many times the program has run 

	textContent = []	# Resets the array to be filled at next call with updated content