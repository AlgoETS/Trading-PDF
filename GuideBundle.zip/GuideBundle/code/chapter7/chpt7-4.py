# Below are the import statements

from bs4 import BeautifulSoup
import requests
import time
from random import randint
import datetime

# Below are the global variables

textContent = []	# Holds the headlines in an array 
cycleCount = 0 		# Stores the frequency of requests made to the server 
tempHeadlineHolder = []	# Array to hold the most recent headline before it has been analyzed

# Below is the input area

def economistSearch():
	page_link = 'https://www.economist.com/'	# Page Url to point request where to crawl 
	page_response = requests.get(page_link, timeout=20)	# Get request to ask for page content
	page_content = BeautifulSoup(page_response.content, "html.parser")	# Ask Beautiful soup to parse for content

	for link in page_content.find_all("span", class_="teaser__headline", limit = 1):	# Finds all the spans with the class flytitle-and-title__title
  		if link.text not in textContent:
			# print("Economist: " + str((link.text).encode("utf-8")))	# Prints the title so we can verify correct operation 
			textContent.append(link.text)	# Appends the headline to our main array 
			tempHeadlineHolder.append(link.text)

	print("Economist Done")
	time.sleep(5) # Creates a crawl delay of 5 seconds (which the Economist requires in their robots.txt file)

def CNNSearch():
	page_link = 'https://www.cnn.com/specials/last-50-stories'	# Page Url to point request where to crawl 
	page_response = requests.get(page_link, timeout=20)	# Get request to ask for page content
	page_content = BeautifulSoup(page_response.content, "html.parser")	# Ask Beautiful soup to parse for content

	for link in page_content.find_all("span", class_="cd__headline-text", limit = 3):	# Finds all the spans with the class cd__headline-text
		if link.text not in textContent:
			# print("CNN: " + str(link.text))	# Prints the title so we can verify correct operation 
			textContent.append(link.text)	# Appends the headline to our main array 
			tempHeadlineHolder.append(link.text) 
	print("CNN Done")

def ReutersSearch():
	page_link = 'https://www.reuters.com/'	# Page Url to point request where to crawl 
	page_response = requests.get(page_link, timeout=20)	# Get request to ask for page content
	page_content = BeautifulSoup(page_response.content, "html.parser")	# Ask Beautiful soup to parse for content

	for link in page_content.find_all("h3", class_="article-heading", limit = 3):	# Finds h3's with the class article-heading
		if link.text not in textContent:
			# print("Reuters: " + str(link.text))	# Prints the title so we can verify correct operation 
			textContent.append(link.text)	# Appends the headline to our main array 
			tempHeadlineHolder.append(link.text) 
	print("Reuters Done")

def AlphaSearch():
	page_link = 'https://seekingalpha.com/market-news/all'	# Page Url to point request where to crawl 
	page_response = requests.get(page_link, timeout=20)		# Get request to ask for page content
	page_content = BeautifulSoup(page_response.content, "html.parser")	# Ask Beautiful soup to parse for content

	for link in page_content.find_all("div", class_="media-body", limit = 3):	# Finds divs with the class media-body
		if link.div.a.text not in textContent:	# Navigates down into the div to get the content in the link and checks if we have seen it before
			# print("Alpha: " + str(link.div.a.text))
   			textContent.append(link.div.a.text)	# Appends the title to our master so we can track if we have seen it before 
			tempHeadlineHolder.append(link.div.a.text)	# Appends the title to our temporary holder which has been cleared after the last unique title
	print("Seeking Alpha Done")

def headlineAnalysis(headline):

	# Splits the headline so we can look for individual word matches
	words = headline.split()

	# A simple count to track if the headline contains our keywords
	matchScore = 0

	# Iterates over the words in the headline and looks for word matches 
	for individualWord in words: 
		if individualWord.lower() == "apple":
			matchScore += 1
		if individualWord.lower() == "exceeds" or individualWord.lower() == "beats":
			matchScore += 1
		if individualWord.lower() == "expectations":
			matchScore += 1

	if matchScore == 3:	# If the headline has three of the keywords then it is a match and should be traded 
		print("-- Trigger Order Execution --")	# This is where we call the orderExecution function 



while True: # Keeps the program constantly monitoring content

	economistSearch()	# Calls our main scraping method 
	CNNSearch()
	ReutersSearch()
	AlphaSearch()	
	cycleCount += 1	 # Tracks the method calls 
	print("Search Done, Cycle: + " + str(cycleCount) + " at: " + str(datetime.datetime.now()))	# An optional printout to keep track of how many times the program has run 

	# You can append text here to test the algorithm's response to certain cases 
	if cycleCount == 12: 
		tempHeadlineHolder.append("Apple exceeds expectations in the latest quarter")

	# A loop that cycles through our temporary headline holder
	for headline in tempHeadlineHolder:
		print("New Headline: " + str(headline))
		headlineAnalysis(headline)

	tempHeadlineHolder = []	# Reset the headline holder after we have searched the content to avoid repeats 

	# (Optional wait time that may be necessary for websites with a crawl delay or bot monitors) 
	time.sleep(randint(0,5))  





















