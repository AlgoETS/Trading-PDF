# Interactive Brokers API Guide
#### Disclaimer *This code is to be used along side the Interactive Brokers API and Beautiful Soup library. The rights to that code do not belong to Corbin Balzan or users of the guide. This guide is written by Corbin Balzan for The Quant Academy. It is not sponsored or authored by Interactive Brokers or its members. The resources are intended to compliment Interactive Brokers API, not replace it in any way. When establishing your account with Interactive Brokers, you must agree to their requirements and restrictions.* 

## General Information: 

This folder is intended to provide the starter code to begin more thorough development on the Interactive Brokers API. The code is written in Python and well commented for easier comprehension. 

The code pairs best with the manual "Guide Interactive Brokers API" by Corbin Balzan. Clear instructions are provided within that text in excess to the comments provided inside the code.

Those familiar with Interactive Brokers may use this code without the associated guide. However, many of the custom functions and conventions may go unexplained.


## Folder Organization: 

Folders are divided by content in relation to their organization in the guide. Each major folder denotes a chapter, with a dash indicating the subsection. Ex)  chpt5-1.py, indicates the code at the first section of Chapter 5.

The code builds slowly, until the final program ibProgram1.py. 

By Chapter, the introduction of information is: 

### Chapter 1, Introduction: 
- Motivations for using the program, included is commented and clean starter code.

### Chapter 2, Installation and Setup:
- TWS and API setup. Included is the API source code for mac. I encourage you to download the latest version for your system from  http://interactivebrokers.github.io/

### Chapter 3, Macrostructure: 
- Sets up the basics of the client, wrapper, test app, imports, and start of execution

### Chapter 4, Adding Order Execution
- Adds the ability to send an order and update with dynamically incrementing IDs

### Chapter 5, Account Data
- Request the account information summary, portfolio holdings, and stores the information so the program can access it

### Chapter 6, Market Information 
- Opens and subscribes to market information. (Note, you will need to activate the subscriptions when you set up your account). 

### Chapter 7, Processing Input: 
- Creates a script to run Beautiful Soup web scraper independently. 

### Chapter 8, Dynamic Model: 
- Incorporates the web scraper into the main program and updates statically coded variables/orders to react more dynamically


## Get Started

To run the code, you must install Beautiful Soup and The Interactive Brokers files: 

### Interactive Brokers
1) Create an account (and get approval)
2) Download the API Files (they are already included as twsapi_macunix, but can be updated to fit your operating system). Link: http://interactivebrokers.github.io/
3) Download the Trader Workstation (this must run on your computer when running the Python script)

### Download Beautiful Soup 
1) Pip install Beautiful Soup
2) Pip install the requests library

### Download Boto3 (If you're using the AWS module code called "db_story.py")
1) In depth application is explained in Guide Book chapter 9. The setup instruction are very similar to (use if you do not have access to the guide):
https://boto3.amazonaws.com/v1/documentation/api/latest/guide/quickstart.html

### Run the Program
After these are done, and the TWS is open, you can run the program as:

python3 ibProgram1.py

Due to difference in operating systems, you may run into a couple configuration errors. The official guide covers many of these potential errors: 
1) Make sure the TWS is configured in preferences to accept incoming connects
2) Your version of python is up to date (need Python 3)
3) All necessary libraries are downloaded




















